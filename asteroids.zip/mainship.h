#ifndef mainship_h
#define mainship_h

#include <QGraphicsItem>

class mainship: public QGraphicsRectItem
{
public:
    void keyPressEvent(QKeyEvent * event);
    int theta;

};

#endif
