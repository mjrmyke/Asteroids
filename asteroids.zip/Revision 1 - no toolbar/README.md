# Asteroids
CSCI 41 Final group project

Okay guys I know it's spring break but make sure you finished the Qt tutorial.
Also look up this timer stuff Mr."30FPS" told us about.

I'll give you guys time to do that while I look up GitHib tutorials and learn how to manage a group programming venture.

Also I plan to have deadline 2 requirements met by Monday so we can make sure we get atleast a C for sure and have plenty of time to implement extras that will get us an A.

~Harpreet
