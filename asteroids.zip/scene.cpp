#include "scene.h"
#include "mainship.h"
#include "bullet.h"

Scene::Scene() : QGraphicsScene()
{

}
